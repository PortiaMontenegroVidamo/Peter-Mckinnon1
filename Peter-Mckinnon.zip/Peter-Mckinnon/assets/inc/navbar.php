    <nav class="menu-web">
        <div class="menu-container">
            <div class="brand-name" >
                <p class="logo"><a href="#">Peter Mckinnon</a></p>
            </div>
            <div class="navbar-menu">
                    <div class="search-bar"><input type="search" name="" id="article-search" placeholder="Search"></div>
                <ul>
                    
                    <li class="menu-btn"><a href="<?php echo ROOT_URL_ADMIN; ?>dashboard/create.php">Create</a><i class="fas fa-pencil-alt"></i></li>
                    <li class="menu-btn"><i href="#" class="profile fas fa-user-circle"></i></li>
                    <li class="menu-btn"><i href="#" class="notification far fa-bell"></i></li>
                </ul>
            </div>
        </div>
    </nav>