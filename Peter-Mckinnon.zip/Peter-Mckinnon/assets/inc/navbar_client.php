<nav class="menu-web ">
        <div class="menu-container">
            <div class="brand-name" >
                <p class="logo"><a href="index.php">Peter Mckinnon</a></p>
            </div>
            <div class="navbar-menu">
                    <div class="search-bar"><input type="search" name="" id="article-search" placeholder="Search"></div>
                <ul>
                   
                    <li class="menu-btn"><a href="#">Articles</a></li>
                    <li class="menu-btn"><a href="#">Profile</a></li>
                    <li class="menu-btn"><a href="#">Contact</a></li>
                </ul>
            </div>
        </div>
        <div class="menu-wrap-hamburger">
            <input type="checkbox" class="toggler">
            <div class="hamburger"><div></div></div>
            <div class="menu">
                <div>
                <div>
                    <ul class="search-bar-right">
                        <li class="menu-btn"><a href="index.php">Home</a></li>
                        <li class="menu-btn"><a href="#">Articles</a></li>
                        <li class="menu-btn"><a href="#">Profile</a></li>
                        <li class="menu-btn"><a href="#">Contact</a></li>
                        <li><input type="search" name="" id="article-search" placeholder="Search"></li>
                    </ul>
                </div>
                </div>
            </div>
        </div>
    </nav>
